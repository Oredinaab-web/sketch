import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ss-sketch-list',
  templateUrl: './sketch-list.component.html',
  styleUrls: ['./sketch-list.component.scss']
})
export class SketchListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
